<?php

$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'hotel_reception_management_system');

?>